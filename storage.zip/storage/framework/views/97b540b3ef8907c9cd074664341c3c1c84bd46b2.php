<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">Dashboard</div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    You are logged in!
                </div>
            </div>
        </div>
        
    </div>
    <div>
            <table id="posttable">
                    
                      <thead>
                        <tr>
                          <th>ID</th>
                          <th>tanggal</th>
                          <th>tipe</th>
                          <th>judul</th>
                          <th>status</th>
                          
                        </tr>
                      </thead>
                      <tbody></tbody>
                    </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
// $(document).ready(function() {
  $("#posttable").DataTable({
    processing: true,
    serverSide: true,
    ajax: '<?php echo e(route('posts')); ?>',
    columns: [
      {data: 'id', name: 'id'},
      {data: 'updated_at', name: 'updated_at'},
      {data: 'type.name', name: 'type_id'},
      {data: 'name', name: 'name'},
      {data: 'active', name: 'active'}
    ]
  });
// });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>