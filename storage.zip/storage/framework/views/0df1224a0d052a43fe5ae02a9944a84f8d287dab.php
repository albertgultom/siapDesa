<?php $__env->startSection('content'); ?>
<div class="nav-middle d-flex flex-nowrap text-nowrap bg-light">
  <a class="p-3" href="/artikel">Daftar Artikel</a>
  
  <a class="p-3" href="/foto">Galeri Foto</a>
  
</div>

<section class="container-fluid nav-section pt-3">
  <?php echo $__env->yieldContent('pustaka'); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>