<?php $__env->startSection('content'); ?>
<section>
  <div class="d-flex flex-row flex-nowrap mb-3 client-logo">
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\siti-aisyah.jpg'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">SITI AISAH, S.IP</div>
        <div class="text-center" style="border-top:1px solid;">Kepala Desa</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\albumtemp-36.jpg'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">ARIS SOMANTRI, S.Pd.I</div>
        <div class="text-center" style="border-top:1px solid;">Sekretaris Desa</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\businessman.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">M. IQBAL AL-HAMDANI</div>
        <div class="text-center" style="border-top:1px solid;">KAUR TU & Umum</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\businesswoman.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">SITI NURHASANAH, A.Md</div>
        <div class="text-center" style="border-top:1px solid;">KAUR Keuangan</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\man-28.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">AS MUCLAS, ST</div>
        <div class="text-center" style="border-top:1px solid;">KAUR Perencanaan</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\woman-2.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">BUMI WIRANTINA</div>
        <div class="text-center" style="border-top:1px solid;">Staf Desa</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\man-5.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">DEDI SETIADI, A.Ma.Pd</div>
        <div class="text-center" style="border-top:1px solid;">Bendahara Desa</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\man-16.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">BENI MULYADI</div>
        <div class="text-center" style="border-top:1px solid;">KASI Pemerintahan</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\man-23.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">MASTUR</div>
        <div class="text-center" style="border-top:1px solid;">KASI Kesejahteraan</div>
    </div>
    <div class="p-3 text-center border border-warning shadow-lite">
        <img src="<?php echo asset('storage\apparatus\man-34.png'); ?>" class="client-img rounded-circle" alt="">
        <div class="text-center" style="min-height: 50px;">AHMAD SAEPUDIN, A.Ma</div>
        <div class="text-center" style="border-top:1px solid;">KASI Pelayanan</div>
    </div>
  </div>
</section>

<div class="container-fluid bg-gradient-ver">
    <div class="sseamless">
        <div class="row card-deck pt-5 pb-5 profil seamless2">
            <div class="card m-2 rounded">
                <div class="card-header">Visi Desa</div>
                <div class="card-body">
                    <ul>
                        <li>Mewujudkan Masyarakat Desa Kujangsari yang Religius, Aspiratif, Inovatif, Efektif, Efisien dan Selaras.</li>
                    </ul>
                </div>
            </div>
            <div class="card m-2 rounded">
                <div class="card-header">Misi Desa</div>
                <div class="card-body">
                    <ul>
                        <li>Membangun sistem pemerintahan yang bersih serta berorientasi kepada pelayanan publik.</li>
                        <li>Menigkatkan kinerja lembaga pemerintahan desa.</li>
                        <li>Meningkatkan laju pemberdayaan ekonomi kerakyatan yang berbasis koperasi.</li>
                    </ul>
                </div>
            </div>
            <div class="card m-2 rounded">
                <div class="card-header">Statisktik Penduduk</div>
                <div class="card-body">
                    <canvas id="chartPenduduk"></canvas>
                </div>
            </div>
            <div class="card m-2 rounded">
                <div class="card-header">Statistik Kepala Keluarga</div>
                <div class="card-body">
                    <canvas id="chartKeluarga"></canvas>
                </div>
            </div>
        </div>
    </div>
</div>




<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    var ctx = document.getElementById("chartPenduduk");
    if(ctx){
        ctx.height = 150;
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["Laki-laki", "Perempuan"],
                datasets: [{
                    data: [5911, 5898],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                legend: {
                    display: false
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
        });
    }
    var ctx = document.getElementById("chartKeluarga");
    if(ctx){
        ctx.height = 150;
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ["Laki-laki", "Perempuan"],
                datasets: [{
                    data: [3717, 337],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                responsive: true,
                legend: {
                    display: false
                },
                scales: {
                    yAxes: [{
                        ticks: {
                            beginAtZero:true
                        }
                    }]
                }
            }
        });
    }
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>