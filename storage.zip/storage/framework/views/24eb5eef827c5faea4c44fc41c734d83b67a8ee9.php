<?php $__env->startSection('content'); ?>
<div class="nav-middle d-flex flex-nowrap text-nowrap bg-light">
  <a class="p-3" href="#">Daftar Artikel</a>
  <a class="p-3" href="#">Daftar Agenda</a>
  <a class="p-3" href="#">Galeri Foto</a>
  <a class="p-3" href="#">Galeri Video</a>
</div>

<section class="container-fluid nav-section">
  <h3>Pustaka Informasi Berita dan Galeri Desa</h3>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>