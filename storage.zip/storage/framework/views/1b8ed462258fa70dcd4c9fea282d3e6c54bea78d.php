<?php $__env->startSection('content'); ?>
<div class="nav-middle d-flex flex-nowrap text-nowrap bg-light">
  <a class="p-3" href="#">Kartu Identitas Anak</a>
  <a class="p-3" href="#">Kartu Tanda Penduduk</a>
  <a class="p-3" href="#">Surat Keterangan Tidak Mampu</a>
</div>

<section class="container-fluid nav-section">
  <h3>Daftar Pelayanan Desa</h3>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.public', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>