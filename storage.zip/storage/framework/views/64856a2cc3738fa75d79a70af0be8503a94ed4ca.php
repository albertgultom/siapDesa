<?php $__env->startSection('profil'); ?>
<div id="identitas">
  <h4 class="title">Sejarah Desa</h4>
  <div>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium mollitia provident hic ex! Assumenda velit aspernatur, possimus, quos debitis illum inventore deserunt distinctio omnis placeat amet deleniti minus ullam magni.</p>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minus tenetur aut excepturi veritatis cum consectetur eaque magni laborum, adipisci, labore vitae pariatur, consequuntur totam doloribus tempora magnam vero ut dignissimos.</p>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eius nobis praesentium corrupti est quae, quo consectetur! Rerum, ullam placeat. Voluptas rem illum repellat quod nostrum. Soluta perspiciatis praesentium vero impedit!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui cumque rem voluptates asperiores, fuga earum architecto est laborum deserunt officia laboriosam doloribus! Perferendis repellat ipsum, praesentium recusandae unde a sed?</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis excepturi rerum ipsa cupiditate animi iste officia sunt facere, asperiores eveniet obcaecati! Obcaecati consectetur expedita quia fuga quaerat asperiores rerum? Saepe.</p>
  </div>
</div>
<div id="perangkat">
  <h4 class="title">Detail Perangkat Desa</h4>
  <div>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium mollitia provident hic ex! Assumenda velit aspernatur, possimus, quos debitis illum inventore deserunt distinctio omnis placeat amet deleniti minus ullam magni.</p>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minus tenetur aut excepturi veritatis cum consectetur eaque magni laborum, adipisci, labore vitae pariatur, consequuntur totam doloribus tempora magnam vero ut dignissimos.</p>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eius nobis praesentium corrupti est quae, quo consectetur! Rerum, ullam placeat. Voluptas rem illum repellat quod nostrum. Soluta perspiciatis praesentium vero impedit!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui cumque rem voluptates asperiores, fuga earum architecto est laborum deserunt officia laboriosam doloribus! Perferendis repellat ipsum, praesentium recusandae unde a sed?</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis excepturi rerum ipsa cupiditate animi iste officia sunt facere, asperiores eveniet obcaecati! Obcaecati consectetur expedita quia fuga quaerat asperiores rerum? Saepe.</p>
  </div>
</div>
<div id="sejarah">
  <h4 class="title">Deskripsi Sejarah Desa</h4>
  <div>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laudantium mollitia provident hic ex! Assumenda velit aspernatur, possimus, quos debitis illum inventore deserunt distinctio omnis placeat amet deleniti minus ullam magni.</p>
    <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Minus tenetur aut excepturi veritatis cum consectetur eaque magni laborum, adipisci, labore vitae pariatur, consequuntur totam doloribus tempora magnam vero ut dignissimos.</p>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Eius nobis praesentium corrupti est quae, quo consectetur! Rerum, ullam placeat. Voluptas rem illum repellat quod nostrum. Soluta perspiciatis praesentium vero impedit!</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui cumque rem voluptates asperiores, fuga earum architecto est laborum deserunt officia laboriosam doloribus! Perferendis repellat ipsum, praesentium recusandae unde a sed?</p>
    <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nobis excepturi rerum ipsa cupiditate animi iste officia sunt facere, asperiores eveniet obcaecati! Obcaecati consectetur expedita quia fuga quaerat asperiores rerum? Saepe.</p>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.profil', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>